package com.example.listmanager;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ListManagerApplication {

	public static void main(String[] args) {
		SpringApplication.run(ListManagerApplication.class, args);
	}

}
