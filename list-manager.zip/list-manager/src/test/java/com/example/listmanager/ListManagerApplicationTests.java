package com.example.listmanager;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ListManagerApplicationTests {

	@Test
	void contextLoads() {
	}

}
